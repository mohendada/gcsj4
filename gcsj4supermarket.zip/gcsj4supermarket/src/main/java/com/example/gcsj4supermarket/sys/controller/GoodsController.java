package com.example.gcsj4supermarket.sys.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author li
 * @since 2024-05-27
 */
@Controller
@RequestMapping("/sys/goods")
public class GoodsController {

}
