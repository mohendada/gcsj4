package com.example.gcsj4supermarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gcsj4supermarketApplicationTests {

    @Test
    void contextLoads() {
    }

}
